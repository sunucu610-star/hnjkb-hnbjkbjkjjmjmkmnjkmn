package com.siparis;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class SiparisCommand implements TabExecutor {

    private final SiparisPlugin plugin;

    public SiparisCommand(SiparisPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Bu komut sadece oyuncular içindir.");
            return true;
        }
        if (!p.hasPermission("siparis.kullan")) {
            Msg.send(p, "<red>Bu komutu kullanma iznin yok.");
            return true;
        }
        if (args.length == 0) {
            Menus.open(plugin, p, MenuHolder.Type.ALL, 0);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "benim", "siparislerim" -> Menus.open(plugin, p, MenuHolder.Type.MINE, 0);
            case "olustur" -> create(p, args);
            default -> help(p);
        }
        return true;
    }

    private void help(Player p) {
        Msg.send(p, "<yellow>/siparis <gray>- tüm siparişleri aç");
        Msg.send(p, "<yellow>/siparis olustur [miktar] [adet fiyatı] <gray>- elindeki eşya için sipariş ver");
        Msg.send(p, "<yellow>/siparis benim <gray>- kendi siparişlerini aç");
    }

    private void create(Player p, String[] args) {
        if (args.length < 3) {
            Msg.send(p, "<red>Kullanım: <yellow>/siparis olustur [miktar] [adet fiyatı]");
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            Msg.send(p, "<red>Önce sipariş vermek istediğin eşyayı elinde tut.");
            return;
        }
        if (hand.hasItemMeta()) {
            Msg.send(p, "<red>İsimli, büyülü veya hasarlı eşyalar için sipariş verilemez. Normal bir eşya tut.");
            return;
        }
        int amount;
        double price;
        try {
            amount = Integer.parseInt(args[1]);
            price = Double.parseDouble(args[2].replace(',', '.'));
        } catch (NumberFormatException ex) {
            Msg.send(p, "<red>Miktar ve fiyat sayı olmalı. Örnek: <yellow>/siparis olustur 64 10");
            return;
        }
        Material m = hand.getType();
        String err = plugin.orders().create(p, m, amount, price);
        if (err != null) {
            Msg.send(p, "<red>" + err);
        }
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("olustur", "benim")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) {
                    out.add(s);
                }
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("olustur")) {
            out.addAll(List.of("1", "16", "64", "128"));
        } else if (args.length == 3 && args[0].equalsIgnoreCase("olustur")) {
            out.addAll(List.of("1", "10", "100"));
        }
        return out;
    }
}
