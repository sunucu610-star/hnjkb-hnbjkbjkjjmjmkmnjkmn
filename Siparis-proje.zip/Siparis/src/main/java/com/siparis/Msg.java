package com.siparis;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.Locale;

public final class Msg {
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private Msg() {
    }

    public static Component c(String s) {
        return MM.deserialize("<!italic>" + s);
    }

    public static Component title(String s) {
        return MM.deserialize(s);
    }

    public static void send(Player p, String s) {
        p.sendMessage(MM.deserialize(
                "<gold><bold>Sipariş</bold></gold> <dark_gray>»</dark_gray> <gray>" + s));
    }

    public static String pretty(Material m) {
        String[] parts = m.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }
}
