package com.siparis;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public final class MenuHolder implements InventoryHolder {

    public enum Type { ALL, MINE }

    public final Type type;
    public int page;
    public final UUID[] slotOrders = new UUID[Menus.PER_PAGE];
    private Inventory inventory;

    public MenuHolder(Type type, int page) {
        this.type = type;
        this.page = page;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}
