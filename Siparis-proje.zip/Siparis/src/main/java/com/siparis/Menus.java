package com.siparis;

import net.kyori.adventure.text.Component;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public final class Menus {

    public static final int PER_PAGE = 45;

    private Menus() {
    }

    public static void open(SiparisPlugin plugin, Player p, MenuHolder.Type type, int page) {
        MenuHolder holder = new MenuHolder(type, page);
        String title = type == MenuHolder.Type.ALL ? "<dark_gray>Siparişler" : "<dark_gray>Siparişlerim";
        Inventory inv = Bukkit.createInventory(holder, 54, Msg.title(title));
        holder.setInventory(inv);
        render(plugin, p, holder);
        p.openInventory(inv);
    }

    public static void render(SiparisPlugin plugin, Player p, MenuHolder holder) {
        Inventory inv = holder.getInventory();
        inv.clear();
        Arrays.fill(holder.slotOrders, null);

        boolean all = holder.type == MenuHolder.Type.ALL;
        List<Order> list = all ? plugin.orders().active() : plugin.orders().ofPlayer(p.getUniqueId());

        int maxPage = Math.max(0, (list.size() - 1) / PER_PAGE);
        holder.page = Math.max(0, Math.min(holder.page, maxPage));

        for (int i = 0; i < PER_PAGE; i++) {
            int idx = holder.page * PER_PAGE + i;
            if (idx >= list.size()) {
                break;
            }
            Order o = list.get(idx);
            holder.slotOrders[i] = o.id;
            inv.setItem(i, all ? allIcon(plugin, p, o) : mineIcon(plugin, o));
        }

        if (list.isEmpty()) {
            inv.setItem(22, item(Material.BARRIER, 1,
                    all ? "<red>Şu an açık sipariş yok" : "<red>Hiç siparişin yok",
                    List.of("<gray>Sipariş vermek için sağdaki kâğıda bak.")));
        }

        ItemStack filler = item(Material.GRAY_STAINED_GLASS_PANE, 1, "<gray> ", List.of());
        for (int s = 45; s < 54; s++) {
            inv.setItem(s, filler);
        }
        if (holder.page > 0) {
            inv.setItem(45, item(Material.ARROW, 1, "<yellow>◀ Önceki sayfa", List.of()));
        }
        if (holder.page < maxPage) {
            inv.setItem(53, item(Material.ARROW, 1, "<yellow>Sonraki sayfa ▶", List.of()));
        }
        if (all) {
            inv.setItem(47, item(Material.CHEST, 1, "<gold>Siparişlerim",
                    List.of("<gray>Verdiğin siparişleri gör,", "<gray>teslim edilenleri al veya iptal et.")));
        } else {
            inv.setItem(47, item(Material.COMPASS, 1, "<gold>Tüm siparişler",
                    List.of("<gray>Herkesin açık siparişlerine dön.")));
        }
        inv.setItem(49, item(Material.PAPER, 1, "<aqua>Nasıl sipariş verilir?", List.of(
                "<gray>İstediğin eşyayı elinde tut ve yaz:",
                "<yellow>/siparis olustur [miktar] [adet fiyatı]",
                "<gray> ",
                "<gray>Örnek: <white>/siparis olustur 64 10",
                "<gray>Toplam para hemen hesabından düşer.")));
        inv.setItem(51, item(Material.OAK_SIGN, 1,
                "<white>Sayfa " + (holder.page + 1) + "/" + (maxPage + 1),
                List.of("<gray>Toplam sipariş: <white>" + list.size())));
    }

    private static ItemStack allIcon(SiparisPlugin plugin, Player p, Order o) {
        boolean own = o.owner.equals(p.getUniqueId());
        List<String> lore = new ArrayList<>();
        lore.add("<gray>Sipariş veren: <white>" + o.ownerName);
        lore.add("<gray>Kalan: <yellow>" + o.remaining + "<gray> / <white>" + o.total);
        lore.add("<gray>Adet fiyatı: <green>" + money(plugin, o.price));
        lore.add("<gray>Kalan toplam ödeme: <green>" + money(plugin, o.remaining * o.price));
        lore.add("<gray> ");
        if (own) {
            lore.add("<red>Bu senin siparişin");
        } else {
            lore.add("<gray>Envanterinde: <white>" + plugin.orders().countItems(p, o.material));
            lore.add("<yellow>▶ Tıkla: teslim et, parayı al");
        }
        return item(o.material, stackSize(o), "<yellow>" + Msg.pretty(o.material) + " <gray>x" + o.remaining, lore);
    }

    private static ItemStack mineIcon(SiparisPlugin plugin, Order o) {
        List<String> lore = new ArrayList<>();
        lore.add("<gray>Kalan: <yellow>" + o.remaining + "<gray> / <white>" + o.total);
        lore.add("<gray>Adet fiyatı: <green>" + money(plugin, o.price));
        lore.add("<gray>Teslim edilen (alınmayı bekleyen): <aqua>" + o.delivered);
        lore.add("<gray> ");
        if (o.remaining <= 0) {
            lore.add("<green>✔ Sipariş tamamlandı");
        }
        lore.add("<yellow>Sol tık: <white>teslim edilenleri al");
        if (o.remaining > 0) {
            lore.add("<red>Sağ tık: <white>siparişi iptal et (kalan para iade)");
        }
        return item(o.material, stackSize(o), "<yellow>" + Msg.pretty(o.material) + " <gray>x" + o.remaining, lore);
    }

    private static int stackSize(Order o) {
        int max = Math.max(1, o.material.getMaxStackSize());
        return Math.max(1, Math.min(o.remaining, max));
    }

    private static String money(SiparisPlugin plugin, double v) {
        Economy eco = plugin.economy();
        double rounded = Math.round(v * 100.0) / 100.0;
        return eco != null ? eco.format(rounded) : String.format(Locale.US, "%.2f", rounded);
    }

    private static ItemStack item(Material m, int amount, String name, List<String> lore) {
        ItemStack it = new ItemStack(m, amount);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Msg.c(name));
        if (!lore.isEmpty()) {
            List<Component> lines = new ArrayList<>();
            for (String s : lore) {
                lines.add(Msg.c(s));
            }
            meta.lore(lines);
        }
        it.setItemMeta(meta);
        return it;
    }
}
