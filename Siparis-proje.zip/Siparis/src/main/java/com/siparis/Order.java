package com.siparis;

import org.bukkit.Material;

import java.util.UUID;

public final class Order {
    public final UUID id;
    public final UUID owner;
    public final String ownerName;
    public final Material material;
    public final int total;
    public int remaining;
    public int delivered;
    public final double price;
    public final long created;

    public Order(UUID id, UUID owner, String ownerName, Material material,
                 int total, int remaining, int delivered, double price, long created) {
        this.id = id;
        this.owner = owner;
        this.ownerName = ownerName;
        this.material = material;
        this.total = total;
        this.remaining = remaining;
        this.delivered = delivered;
        this.price = price;
        this.created = created;
    }
}
