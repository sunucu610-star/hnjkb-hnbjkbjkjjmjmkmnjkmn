package com.siparis;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class SiparisPlugin extends JavaPlugin {

    private OrderManager orders;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        orders = new OrderManager(this);
        orders.load();

        SiparisCommand cmd = new SiparisCommand(this);
        PluginCommand pc = getCommand("siparis");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }
        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
        getLogger().info("Siparis eklentisi açıldı. Yüklenen sipariş sayısı: " + orders.size());
    }

    @Override
    public void onDisable() {
        if (orders != null) {
            orders.save();
        }
    }

    public OrderManager orders() {
        return orders;
    }

    public Economy economy() {
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        return rsp == null ? null : rsp.getProvider();
    }
}
