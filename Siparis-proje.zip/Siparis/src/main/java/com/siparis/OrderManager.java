package com.siparis;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class OrderManager {

    private final SiparisPlugin plugin;
    private final Map<UUID, Order> orders = new LinkedHashMap<>();
    private final File file;

    public OrderManager(SiparisPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "orders.yml");
    }

    public int size() {
        return orders.size();
    }

    public Order get(UUID id) {
        return orders.get(id);
    }

    public List<Order> active() {
        List<Order> list = new ArrayList<>();
        for (Order o : orders.values()) {
            if (o.remaining > 0) {
                list.add(o);
            }
        }
        list.sort(Comparator.comparingLong((Order o) -> o.created).reversed());
        return list;
    }

    public List<Order> ofPlayer(UUID owner) {
        List<Order> list = new ArrayList<>();
        for (Order o : orders.values()) {
            if (o.owner.equals(owner)) {
                list.add(o);
            }
        }
        list.sort(Comparator.comparingLong((Order o) -> o.created));
        return list;
    }

    public int pendingDelivered(UUID owner) {
        int sum = 0;
        for (Order o : orders.values()) {
            if (o.owner.equals(owner)) {
                sum += o.delivered;
            }
        }
        return sum;
    }

    public void load() {
        orders.clear();
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = yml.getConfigurationSection("orders");
        if (sec == null) {
            return;
        }
        for (String key : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(key);
            if (s == null) {
                continue;
            }
            try {
                Material m = Material.matchMaterial(s.getString("material", ""));
                if (m == null) {
                    continue;
                }
                Order o = new Order(
                        UUID.fromString(key),
                        UUID.fromString(s.getString("owner", "")),
                        s.getString("ownerName", "?"),
                        m,
                        s.getInt("total"),
                        s.getInt("remaining"),
                        s.getInt("delivered"),
                        s.getDouble("price"),
                        s.getLong("created"));
                orders.put(o.id, o);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Bozuk sipariş atlandı: " + key);
            }
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Order o : orders.values()) {
            String base = "orders." + o.id + ".";
            yml.set(base + "owner", o.owner.toString());
            yml.set(base + "ownerName", o.ownerName);
            yml.set(base + "material", o.material.name());
            yml.set(base + "total", o.total);
            yml.set(base + "remaining", o.remaining);
            yml.set(base + "delivered", o.delivered);
            yml.set(base + "price", o.price);
            yml.set(base + "created", o.created);
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("orders.yml kaydedilemedi: " + ex.getMessage());
        }
    }

    private static double round(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    private String money(double v) {
        Economy eco = plugin.economy();
        return eco != null ? eco.format(v) : String.format(java.util.Locale.US, "%.2f", v);
    }

    private static boolean plain(ItemStack it, Material m) {
        return it != null && it.getType() == m && !it.hasItemMeta();
    }

    public int countItems(Player p, Material m) {
        int c = 0;
        for (ItemStack it : p.getInventory().getStorageContents()) {
            if (plain(it, m)) {
                c += it.getAmount();
            }
        }
        return c;
    }

    private void takeItems(Player p, Material m, int amount) {
        ItemStack[] contents = p.getInventory().getStorageContents();
        int left = amount;
        for (int i = 0; i < contents.length && left > 0; i++) {
            ItemStack it = contents[i];
            if (!plain(it, m)) {
                continue;
            }
            int take = Math.min(left, it.getAmount());
            if (take >= it.getAmount()) {
                contents[i] = null;
            } else {
                it.setAmount(it.getAmount() - take);
            }
            left -= take;
        }
        p.getInventory().setStorageContents(contents);
    }

    private void giveItems(Player p, Material m, int amount) {
        int max = Math.max(1, m.getMaxStackSize());
        int left = amount;
        while (left > 0) {
            int size = Math.min(left, max);
            Map<Integer, ItemStack> over = p.getInventory().addItem(new ItemStack(m, size));
            for (ItemStack extra : over.values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), extra);
            }
            left -= size;
        }
    }

    public String create(Player p, Material m, int amount, double rawPrice) {
        Economy eco = plugin.economy();
        if (eco == null) {
            return "Ekonomi sistemi bulunamadı. Sunucuda Vault ve bir ekonomi eklentisi (EssentialsX gibi) olmalı.";
        }
        int maxOrders = plugin.getConfig().getInt("max-siparis-per-oyuncu", 5);
        if (ofPlayer(p.getUniqueId()).size() >= maxOrders) {
            return "En fazla " + maxOrders + " siparişin olabilir. Birini iptal et ya da tamamlanmasını bekle.";
        }
        int maxAmount = plugin.getConfig().getInt("max-miktar", 2304);
        if (amount < 1 || amount > maxAmount) {
            return "Miktar 1 ile " + maxAmount + " arasında olmalı.";
        }
        double price = round(rawPrice);
        double maxPrice = plugin.getConfig().getDouble("max-adet-fiyati", 1000000);
        if (price <= 0 || price > maxPrice) {
            return "Adet fiyatı 0.01 ile " + money(maxPrice) + " arasında olmalı.";
        }
        double total = round(amount * price);
        if (!eco.has(p, total)) {
            return "Yeterli paran yok. Gereken: " + money(total);
        }
        EconomyResponse r = eco.withdrawPlayer(p, total);
        if (!r.transactionSuccess()) {
            return "Para çekilemedi: " + r.errorMessage;
        }
        Order o = new Order(UUID.randomUUID(), p.getUniqueId(), p.getName(), m,
                amount, amount, 0, price, System.currentTimeMillis());
        orders.put(o.id, o);
        save();
        Msg.send(p, "<green>Siparişin oluşturuldu: <yellow>" + amount + "x " + Msg.pretty(m)
                + "<green> (adet " + money(price) + "). Toplam <yellow>" + money(total) + "<green> bloke edildi.");
        return null;
    }

    public void fill(Player p, Order o) {
        Economy eco = plugin.economy();
        if (eco == null) {
            Msg.send(p, "<red>Ekonomi sistemi bulunamadı.");
            return;
        }
        if (o.owner.equals(p.getUniqueId())) {
            Msg.send(p, "<red>Kendi siparişini dolduramazsın.");
            return;
        }
        if (o.remaining <= 0) {
            Msg.send(p, "<red>Bu sipariş zaten tamamlanmış.");
            return;
        }
        int have = countItems(p, o.material);
        if (have <= 0) {
            Msg.send(p, "<red>Envanterinde teslim edilecek <yellow>" + Msg.pretty(o.material)
                    + "<red> yok. <gray>(İsimli veya büyülü eşyalar kabul edilmez.)");
            return;
        }
        int n = Math.min(have, o.remaining);
        double pay = round(n * o.price);
        takeItems(p, o.material, n);
        eco.depositPlayer(p, pay);
        o.remaining -= n;
        o.delivered += n;
        save();

        Msg.send(p, "<green><yellow>" + n + "x " + Msg.pretty(o.material) + "<green> teslim ettin ve <yellow>"
                + money(pay) + "<green> kazandın!");
        Player owner = Bukkit.getPlayer(o.owner);
        if (owner != null && owner.isOnline()) {
            Msg.send(owner, "<yellow>" + p.getName() + "<green> siparişine <yellow>" + n + "x "
                    + Msg.pretty(o.material) + "<green> teslim etti! <gray>(/siparis benim)");
        }
    }

    public void collect(Player p, Order o) {
        if (!o.owner.equals(p.getUniqueId())) {
            return;
        }
        if (o.delivered <= 0) {
            Msg.send(p, "<gray>Alınacak teslim edilmiş eşya yok.");
            return;
        }
        int got = o.delivered;
        giveItems(p, o.material, got);
        o.delivered = 0;
        if (o.remaining <= 0) {
            orders.remove(o.id);
        }
        save();
        Msg.send(p, "<green><yellow>" + got + "x " + Msg.pretty(o.material) + "<green> teslim aldın.");
    }

    public void cancel(Player p, Order o) {
        if (!o.owner.equals(p.getUniqueId())) {
            return;
        }
        double refund = round(o.remaining * o.price);
        if (refund > 0) {
            Economy eco = plugin.economy();
            if (eco == null) {
                Msg.send(p, "<red>Ekonomi sistemi bulunamadı, iptal edilemedi.");
                return;
            }
            eco.depositPlayer(p, refund);
        }
        int got = o.delivered;
        if (got > 0) {
            giveItems(p, o.material, got);
        }
        orders.remove(o.id);
        save();
        Msg.send(p, "<green>Sipariş iptal edildi. <yellow>" + money(refund) + "<green> iade edildi"
                + (got > 0 ? ", <yellow>" + got + "x " + Msg.pretty(o.material) + "<green> teslim aldın." : "."));
    }
}
