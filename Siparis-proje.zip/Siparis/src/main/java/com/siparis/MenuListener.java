package com.siparis;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;

import java.util.UUID;

public final class MenuListener implements Listener {

    private final SiparisPlugin plugin;

    public MenuListener(SiparisPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof MenuHolder holder)) {
            return;
        }
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) {
            return;
        }
        if (e.getClickedInventory() != top) {
            return;
        }
        int slot = e.getSlot();

        if (slot >= 0 && slot < Menus.PER_PAGE) {
            UUID id = holder.slotOrders[slot];
            if (id == null) {
                return;
            }
            Order o = plugin.orders().get(id);
            if (o == null) {
                Msg.send(p, "<red>Bu sipariş artık yok.");
            } else if (holder.type == MenuHolder.Type.ALL) {
                plugin.orders().fill(p, o);
            } else if (e.isRightClick()) {
                if (o.remaining > 0) {
                    plugin.orders().cancel(p, o);
                }
            } else {
                plugin.orders().collect(p, o);
            }
            Menus.render(plugin, p, holder);
            return;
        }

        switch (slot) {
            case 45 -> {
                if (holder.page > 0) {
                    holder.page--;
                    Menus.render(plugin, p, holder);
                }
            }
            case 53 -> {
                holder.page++;
                Menus.render(plugin, p, holder);
            }
            case 47 -> {
                MenuHolder.Type next = holder.type == MenuHolder.Type.ALL
                        ? MenuHolder.Type.MINE : MenuHolder.Type.ALL;
                plugin.getServer().getScheduler().runTask(plugin, () -> Menus.open(plugin, p, next, 0));
            }
            case 49 -> {
                p.closeInventory();
                Msg.send(p, "<yellow>Elinde istediğin eşyayı tut ve yaz: <white>/siparis olustur [miktar] [adet fiyatı]");
            }
            default -> {
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof MenuHolder) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        int pending = plugin.orders().pendingDelivered(p.getUniqueId());
        if (pending > 0) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (p.isOnline()) {
                    Msg.send(p, "<green>Siparişlerine toplam <yellow>" + pending
                            + "<green> eşya teslim edilmiş! <gray>(/siparis benim)");
                }
            }, 60L);
        }
    }
}
